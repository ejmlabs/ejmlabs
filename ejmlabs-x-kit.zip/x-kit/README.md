# ejmlabs X kit

Sage and Forest edition. Built from the original ejmlabs vector artwork and brand guide.

## Upload these first

| X field | File | Size |
| --- | --- | --- |
| Profile image | `UPLOAD-avatar.png` | 400 x 400 |
| Header | `UPLOAD-header.png` | 1500 x 500 |
| Display name | ejmlabs | |
| Website | https://ejmlabs.com/ | |

The suggested handle is `@ejmlabs`; availability has not been checked. Use `profile-copy.md` for bio and pinned introduction drafts. Nothing has been published or changed on X.

## Assets

- `avatars/`: Forest and Paper avatars at 400 and 1024 px, with vector originals. Both fit the circular crop and preserve the symbol's required clear space.
- `banners/`: Forest and Paper headers at 1500 x 500. The primary version pairs the Paper logo with a Sage symbol crop on Forest.
- `posts/signature-1600x900.png`: a ready-to-use signature graphic.
- `posts/project-template-1600x900.png`: a project announcement layout. Replace “Project name” and its description before publishing.
- `source/editable/`: live-text SVG versions of the headers and posts.
- `source/logos/`: unchanged original vector logo paths.
- `fonts/`: complete licensed brand fonts for editing.
- `guides/banner-safe-area.png`: a guide only. Do not upload it as the header.
- `previews/`: profile and asset previews. These are mockups, not screenshots of a live account.

## Crop guidance

X can crop headers differently across screens and place the profile image over the lower-left portion. Essential copy is concentrated in the middle of the header, away from the edges and avatar overlap. The guide marks a conservative central content region and 60 px top and bottom crop bands. This is a design allowance, not a promise that every X client uses the same crop.

Upload at the supplied dimensions, inspect both desktop and mobile, and leave the image at its natural scale when possible. Keep the original logo proportional. The full wordmark is custom artwork, not typed text.

## Editing

Install Manrope and IBM Plex Mono from `fonts/`, then open the SVGs in `source/editable/` in a vector editor. Copy can be changed there. Production SVGs in `banners/` and `posts/` have outlined text for reliable rendering.

Colors: Sage `#8A9A7B`, Forest `#29443B`, Ink `#202721`, Paper `#F6F5EF`, Mist `#E8EDE3`. The two themes are alternatives. Start with Forest for a consistent profile.

## Suggested image descriptions

- Avatar: “The ejmlabs e symbol in warm white on a forest green background.”
- Header: “ejmlabs. Small experiments. Useful things. A sage green symbol curves across a forest green background.”
- Signature post: “Small experiments. Useful things. The ejmlabs logo and a cropped sage green symbol on warm white.”

The original identity belongs to its owner. Fonts retain their included SIL Open Font Licenses. The main design kit records extraction details and source provenance.
