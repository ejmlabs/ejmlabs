use std::{
    cell::{Cell, RefCell},
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, AtomicUsize, Ordering},
    },
};

use ejm_harness_auth::VaultKeyStore;

use super::*;

#[derive(Default)]
struct FixtureLegacy {
    token: RefCell<Option<SecretString>>,
    identity: RefCell<Option<Zeroizing<Vec<u8>>>>,
    reads: Cell<usize>,
    deletes: Cell<usize>,
    deny_delete: bool,
}

impl FixtureLegacy {
    fn populated() -> Self {
        Self {
            token: RefCell::new(Some(SecretString::new("synthetic-relay-private-token"))),
            identity: RefCell::new(Some(Zeroizing::new(vec![0x35; 32]))),
            ..Self::default()
        }
    }
}

impl Legacy for FixtureLegacy {
    fn token(&self) -> Result<Option<SecretString>> {
        self.reads.set(self.reads.get() + 1);
        Ok(self.token.borrow().clone())
    }

    fn identity(&self) -> Result<Option<Zeroizing<Vec<u8>>>> {
        self.reads.set(self.reads.get() + 1);
        Ok(self.identity.borrow().clone())
    }

    fn delete_token(&self) -> Result<()> {
        self.deletes.set(self.deletes.get() + 1);
        ensure!(!self.deny_delete, "synthetic cleanup denial");
        self.token.replace(None);
        Ok(())
    }

    fn delete_identity(&self) -> Result<()> {
        self.deletes.set(self.deletes.get() + 1);
        ensure!(!self.deny_delete, "synthetic cleanup denial");
        self.identity.replace(None);
        Ok(())
    }
}

fn origin() -> RelayOrigin {
    RelayOrigin::parse("https://synthetic-relay.example").unwrap()
}

fn metadata() -> CachedAccount {
    CachedAccount {
        origin: origin().as_str().into(),
        account_id: "synthetic-account".into(),
        device_id: "synthetic-device".into(),
    }
}

#[test]
fn old_writer_exclusion_is_required_before_any_store_access() {
    let vault = SecretVault::memory();
    let legacy = FixtureLegacy::populated();
    assert!(migrate_into(&vault, &origin(), Some(&metadata()), &legacy, false).is_err());
    assert_eq!(legacy.reads.get(), 0);
    assert_eq!(legacy.deletes.get(), 0);
    let tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    assert!(tx.get(&id(&origin(), TOKEN).unwrap()).is_none());
    assert!(!tx.migrated(&id(&origin(), TOKEN).unwrap()));
}

#[test]
fn migration_preserves_account_device_and_fingerprint_with_isolated_authority() {
    let vault = SecretVault::memory();
    let legacy = FixtureLegacy::populated();
    let fingerprint = EndpointIdentity::from_saved(&[0x35; 32])
        .unwrap()
        .fingerprint();
    assert!(migrate_into(&vault, &origin(), Some(&metadata()), &legacy, true).unwrap());
    assert_eq!(legacy.deletes.get(), 2);
    let tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    let value = tx.get(&id(&origin(), TOKEN).unwrap()).unwrap();
    assert_eq!(
        account_token(&value, &metadata()).unwrap().expose_secret(),
        "synthetic-relay-private-token"
    );
    let key = tx.get(&id(&origin(), IDENTITY).unwrap()).unwrap();
    assert_eq!(
        EndpointIdentity::from_saved(key.expose_secret().as_bytes())
            .unwrap()
            .fingerprint(),
        fingerprint
    );
    for key in [
        id(&RelayOrigin::parse("https://other.example").unwrap(), TOKEN).unwrap(),
        id(&origin(), "other-purpose").unwrap(),
        SecretId::new("ejm-cli-registry", TOKEN, origin().as_str()).unwrap(),
        SecretId::new("provider-auth", TOKEN, origin().as_str()).unwrap(),
    ] {
        assert!(tx.get(&key).is_none());
        assert!(!tx.migrated(&key));
    }
    let mut other_device = metadata();
    other_device.device_id = "different-device".into();
    assert!(account_token(&value, &other_device).is_err());
    assert!(account_token(&SecretString::new("malformed-private-value"), &metadata()).is_err());
}

#[test]
fn identity_conflict_leaves_both_legacy_entries_and_no_partial_token_commit() {
    let vault = SecretVault::memory();
    let identity_id = id(&origin(), IDENTITY).unwrap();
    let existing = EndpointIdentity::from_saved(&[0x70; 32]).unwrap();
    let mut tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    tx.set(identity_id.clone(), existing.saved_value().unwrap())
        .unwrap();
    tx.commit().unwrap();
    drop(tx);
    let legacy = FixtureLegacy::populated();
    let error = migrate_into(&vault, &origin(), Some(&metadata()), &legacy, true).unwrap_err();
    assert!(error.to_string().contains("conflicting relay endpoint"));
    assert_eq!(legacy.deletes.get(), 0);
    let tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    assert!(tx.get(&id(&origin(), TOKEN).unwrap()).is_none());
    assert!(!tx.migrated(&id(&origin(), TOKEN).unwrap()));
    let saved = tx.get(&identity_id).unwrap();
    assert_eq!(
        EndpointIdentity::from_saved(saved.expose_secret().as_bytes())
            .unwrap()
            .public_key(),
        existing.public_key()
    );
}

#[test]
fn token_conflict_or_missing_metadata_retains_legacy_credentials() {
    let vault = SecretVault::memory();
    let legacy = FixtureLegacy::populated();
    assert!(migrate_into(&vault, &origin(), None, &legacy, true).is_err());
    assert_eq!(legacy.deletes.get(), 0);
    let mut tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    tx.set(
        id(&origin(), TOKEN).unwrap(),
        account_value(&metadata(), &SecretString::new("other-private-token")).unwrap(),
    )
    .unwrap();
    tx.commit().unwrap();
    drop(tx);
    assert!(migrate_into(&vault, &origin(), Some(&metadata()), &legacy, true).is_err());
    assert_eq!(legacy.deletes.get(), 0);
}

#[test]
fn failed_cleanup_and_logout_cannot_reimport_stale_tokens() {
    let vault = SecretVault::memory();
    let legacy = FixtureLegacy {
        deny_delete: true,
        ..FixtureLegacy::populated()
    };
    assert!(!migrate_into(&vault, &origin(), Some(&metadata()), &legacy, true).unwrap());
    let token_id = id(&origin(), TOKEN).unwrap();
    let mut tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    assert!(tx.migrated(&token_id));
    tx.delete(&token_id);
    tx.commit().unwrap();
    drop(tx);
    let reads = legacy.reads.get();
    assert!(!migrate_into(&vault, &origin(), None, &legacy, true).unwrap());
    assert_eq!(legacy.reads.get(), reads);
    let tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    assert!(tx.get(&token_id).is_none());
    assert!(tx.migrated(&token_id));
    assert!(tx.get(&id(&origin(), IDENTITY).unwrap()).is_some());
}

#[derive(Default)]
struct FixtureKeys {
    key: Mutex<Option<SecretString>>,
    deny_save: AtomicBool,
    saves: AtomicUsize,
}

impl VaultKeyStore for FixtureKeys {
    fn get(&self, _vault_id: &str) -> Result<Option<SecretString>> {
        Ok(self.key.lock().unwrap().clone())
    }

    fn set(&self, _vault_id: &str, key: &SecretString) -> Result<()> {
        self.saves.fetch_add(1, Ordering::SeqCst);
        ensure!(
            !self.deny_save.load(Ordering::SeqCst),
            "synthetic native key denial"
        );
        self.key.lock().unwrap().replace(key.clone());
        Ok(())
    }
}

#[test]
fn persisted_upgrade_reloads_before_cleanup_and_missing_key_never_regenerates() {
    let state = tempfile::tempdir().unwrap();
    let root = state.path().join("state ü with spaces");
    let keys = Arc::new(FixtureKeys::default());
    let vault = SecretVault::open_with_key_store(&root, keys.clone()).unwrap();
    let legacy = FixtureLegacy::populated();
    assert!(migrate_into(&vault, &origin(), Some(&metadata()), &legacy, true).unwrap());
    drop(vault);
    let vault = SecretVault::open_with_key_store(&root, keys.clone()).unwrap();
    let tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    let value = tx.get(&id(&origin(), TOKEN).unwrap()).unwrap();
    assert_eq!(
        account_token(&value, &metadata()).unwrap().expose_secret(),
        "synthetic-relay-private-token"
    );
    drop(tx);
    keys.key.lock().unwrap().take();
    let saves = keys.saves.load(Ordering::SeqCst);
    let retry = FixtureLegacy::populated();
    let error = migrate_into(&vault, &origin(), Some(&metadata()), &retry, true).unwrap_err();
    assert!(error.to_string().contains("do not replace a missing key"));
    assert!(!error.to_string().contains("synthetic-relay-private-token"));
    assert_eq!(keys.saves.load(Ordering::SeqCst), saves);
    assert_eq!(retry.deletes.get(), 0);
    assert_eq!(retry.reads.get(), 0);
}

#[test]
fn fresh_preparation_persists_identity_and_is_idempotent() {
    let state = tempfile::tempdir().unwrap();
    let root = state.path().join("auth");
    let keys = Arc::new(FixtureKeys::default());
    let vault = SecretVault::open_with_key_store(&root, keys.clone()).unwrap();
    assert!(
        load_identity(&vault, &origin())
            .unwrap_err()
            .to_string()
            .contains("remote migrate-credentials")
    );
    let legacy = FixtureLegacy::default();
    assert!(migrate_into(&vault, &origin(), None, &legacy, true).unwrap());
    let fingerprint = load_identity(&vault, &origin()).unwrap().fingerprint();
    drop(vault);

    let reopened = SecretVault::open_with_key_store(&root, keys).unwrap();
    assert!(migrate_into(&reopened, &origin(), None, &legacy, true).unwrap());
    assert_eq!(
        load_identity(&reopened, &origin()).unwrap().fingerprint(),
        fingerprint
    );
    let tx = reopened.lock_blocking(&CancellationToken::new()).unwrap();
    assert!(tx.migrated(&id(&origin(), IDENTITY).unwrap()));
    assert!(tx.migrated(&id(&origin(), TOKEN).unwrap()));
    assert!(tx.get(&id(&origin(), TOKEN).unwrap()).is_none());
}

#[test]
fn preparation_preserves_existing_identity_without_legacy_entry() {
    let vault = SecretVault::memory();
    let identity_id = id(&origin(), IDENTITY).unwrap();
    let existing = EndpointIdentity::from_saved(&[0x70; 32]).unwrap();
    let mut tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    tx.set(identity_id.clone(), existing.saved_value().unwrap())
        .unwrap();
    tx.commit().unwrap();
    drop(tx);

    assert!(migrate_into(&vault, &origin(), None, &FixtureLegacy::default(), true).unwrap());
    assert_eq!(
        load_identity(&vault, &origin()).unwrap().public_key(),
        existing.public_key()
    );
    let tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    assert!(tx.migrated(&identity_id));
}

#[test]
fn missing_marked_identity_requires_recovery_without_legacy_access() {
    let vault = SecretVault::memory();
    let identity_id = id(&origin(), IDENTITY).unwrap();
    let mut tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    tx.mark_migrated(identity_id.clone()).unwrap();
    tx.commit().unwrap();
    drop(tx);

    assert!(
        load_identity(&vault, &origin())
            .unwrap_err()
            .to_string()
            .contains("restore the original vault")
    );
    let legacy = FixtureLegacy::populated();
    let error = migrate_into(&vault, &origin(), Some(&metadata()), &legacy, true).unwrap_err();
    assert!(error.to_string().contains("restore the original vault"));
    assert_eq!(legacy.reads.get(), 0);
    assert_eq!(legacy.deletes.get(), 0);
    let tx = vault.lock_blocking(&CancellationToken::new()).unwrap();
    assert!(tx.migrated(&identity_id));
    assert!(tx.get(&identity_id).is_none());
    assert!(tx.get(&id(&origin(), TOKEN).unwrap()).is_none());
    assert!(!tx.migrated(&id(&origin(), TOKEN).unwrap()));
}

#[test]
fn denied_key_creation_keeps_legacy_credentials_recoverable() {
    let state = tempfile::tempdir().unwrap();
    let keys = Arc::new(FixtureKeys {
        deny_save: AtomicBool::new(true),
        ..FixtureKeys::default()
    });
    let vault = SecretVault::open_with_key_store(state.path().join("auth"), keys).unwrap();
    let legacy = FixtureLegacy::populated();
    assert!(migrate_into(&vault, &origin(), Some(&metadata()), &legacy, true).is_err());
    assert_eq!(legacy.deletes.get(), 0);
    assert_eq!(legacy.reads.get(), 0);
}
