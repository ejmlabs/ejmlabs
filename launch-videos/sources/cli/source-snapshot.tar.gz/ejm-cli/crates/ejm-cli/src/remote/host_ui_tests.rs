//! Lifecycle regressions use held tasks and an offline public harness.
use super::*;
use anyhow::{Context, Result};
use clap::Parser;
use ejm_harness::{Harness, HarnessConfig, ReplayProvider, Session, SessionOptions};
use std::{sync::Arc, time::Duration};

const NOW: u64 = 1000;
const EXPIRES: u64 = 2000;

async fn backend() -> Result<(tempfile::TempDir, LocalBackend, Session)> {
    let directory = tempfile::tempdir()?;
    let harness = Harness::new(
        HarnessConfig {
            state_dir: directory.path().join("sessions"),
            ..HarnessConfig::default()
        },
        Arc::new(ReplayProvider::echo()),
        vec![],
    )?;
    let session = harness
        .create_session(SessionOptions {
            cwd: directory.path().into(),
            title: "host lifecycle".into(),
        })
        .await?;
    Ok((directory, LocalBackend::new(harness), session))
}

fn held_task(epoch: &str) -> (HostTask, mpsc::Sender<HostNotice>, oneshot::Sender<()>) {
    let (sender, notices) = mpsc::channel(4);
    let (release, receive) = oneshot::channel();
    let join = tokio::spawn(async move {
        let _ = receive.await;
    });
    (
        HostTask {
            epoch: epoch.into(),
            expires_at_ms: EXPIRES,
            notices,
            join,
        },
        sender,
        release,
    )
}

fn host(session: &Session, task: HostTask) -> HostUi {
    HostUi {
        account: None,
        session: Some(session.id.clone()),
        role: ShareRole::Control,
        connected: true,
        panel: Some(Panel {
            title: "Private invitation".into(),
            body: Zeroizing::new("fixture invitation".into()),
            answer: None,
        }),
        cancel: CancellationToken::new(),
        task: Some(task),
    }
}

async fn finish(host: &mut HostUi, release: oneshot::Sender<()>) -> Result<()> {
    release
        .send(())
        .map_err(|()| anyhow::anyhow!("task already ended"))?;
    tokio::time::timeout(Duration::from_secs(3), async {
        while host
            .task
            .as_ref()
            .is_some_and(|task| !task.join.is_finished())
        {
            tokio::task::yield_now().await;
        }
    })
    .await?;
    Ok(())
}

#[tokio::test]
async fn failure_keeps_task_until_join_and_old_notices_cannot_hide_replacement() -> Result<()> {
    let (_directory, backend, session) = backend().await?;
    backend
        .begin_share(&session.id, "old".into(), ShareRole::Control, EXPIRES)
        .await?;
    let (task, old_sender, release) = held_task("old");
    let mut host = host(&session, task);
    let mut app = App::new(session.clone());
    old_sender.send(HostNotice::Failed).await?;
    host.poll(&mut app, &backend, NOW).await;
    assert!(
        host.task.is_some(),
        "a completion notice cannot detach its task"
    );
    assert!(host.session.is_none());
    assert!(host.panel.is_none());
    assert!(app.remote.is_none());
    let args = Args::try_parse_from(["ejm-cli"])?;
    assert!(
        host.share(&backend, &args, &session.id, ShareRole::View)
            .await
            .is_err()
    );

    finish(&mut host, release).await?;
    host.poll(&mut app, &backend, NOW).await;
    assert!(host.task.is_none());
    assert!(backend.shared_session().await.is_none());

    backend
        .begin_share(&session.id, "new".into(), ShareRole::Control, EXPIRES)
        .await?;
    let (task, _new_sender, release) = held_task("new");
    host.session = Some(session.id.clone());
    host.cancel = CancellationToken::new();
    host.task = Some(task);
    // The old receiver was dropped only after its task was joined.
    assert!(old_sender.send(HostNotice::Failed).await.is_err());
    host.poll(&mut app, &backend, NOW).await;
    assert!(app.remote.is_some());
    assert!(!backend.stop_share_if("old").await);
    assert!(backend.is_current_share("new", &session.id, NOW).await);
    finish(&mut host, release).await?;
    host.poll(&mut app, &backend, NOW).await;
    backend.shutdown().await?;
    Ok(())
}

#[tokio::test]
async fn expiry_revokes_and_clears_pairing_before_slow_cleanup_finishes() -> Result<()> {
    let (_directory, backend, session) = backend().await?;
    backend
        .begin_share(&session.id, "expiring".into(), ShareRole::View, EXPIRES)
        .await?;
    let (task, sender, release) = held_task("expiring");
    let mut host = host(&session, task);
    let mut app = App::new(session.clone());
    let (answer, mut receive) = oneshot::channel();
    host.panel.as_mut().context("pairing panel missing")?.answer = Some(answer);
    host.poll(&mut app, &backend, EXPIRES).await;
    assert!(backend.shared_session().await.is_none());
    assert!(host.cancel.is_cancelled());
    assert!(
        host.task.is_some(),
        "slow cleanup still owns its task handle"
    );
    assert!(host.session.is_none());
    assert!(host.panel.is_none());
    assert!(!host.connected);
    assert!(app.remote.is_none());
    assert!(matches!(
        receive.try_recv(),
        Err(oneshot::error::TryRecvError::Closed)
    ));

    sender.send(HostNotice::Connected).await?;
    host.poll(&mut app, &backend, EXPIRES).await;
    assert!(
        app.remote.is_none(),
        "late notices cannot restore an expired share"
    );
    finish(&mut host, release).await?;
    host.poll(&mut app, &backend, EXPIRES).await;
    assert!(host.task.is_none());
    backend.shutdown().await?;
    Ok(())
}

#[tokio::test]
async fn finished_old_task_cleanup_does_not_revoke_a_replacement_epoch() -> Result<()> {
    let (_directory, backend, session) = backend().await?;
    backend
        .begin_share(&session.id, "replacement".into(), ShareRole::View, EXPIRES)
        .await?;
    let (task, _sender, release) = held_task("old");
    let mut host = host(&session, task);
    let mut app = App::new(session.clone());
    finish(&mut host, release).await?;
    host.poll(&mut app, &backend, NOW).await;
    assert!(host.task.is_none());
    assert!(
        backend
            .is_current_share("replacement", &session.id, NOW)
            .await
    );
    assert!(backend.stop_share_if("replacement").await);
    backend.shutdown().await?;
    Ok(())
}

#[derive(serde::Deserialize, zeroize::Zeroize, zeroize::ZeroizeOnDrop)]
#[serde(deny_unknown_fields)]
struct RemoteTerminalConfig {
    input: String,
}

fn terminal_config() -> Result<RemoteTerminalConfig> {
    let path = std::env::var_os("EJM_REMOTE_TERMINAL_CONFIG")
        .context("remote terminal fixture needs a private configuration file")?;
    let bytes = Zeroizing::new(std::fs::read(path)?);
    anyhow::ensure!(
        bytes.len() <= 4096,
        "invalid remote terminal fixture config"
    );
    serde_json::from_slice(&bytes).context("invalid remote terminal fixture config")
}

async fn terminal_input(terminal: &mut crate::ui::TerminalGuard) -> Result<Event> {
    tokio::time::timeout(Duration::from_secs(10), async {
        loop {
            if terminal.poll_input()? {
                return terminal.read_input();
            }
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
    })
    .await?
}

async fn terminal_panel(terminal: &mut crate::ui::TerminalGuard, host: &mut HostUi) -> Result<()> {
    terminal.reset_input()?;
    while host.panel.is_some() {
        terminal.terminal.draw(|frame| host.draw(frame))?;
        host.handle_panel(&terminal_input(terminal).await?);
    }
    terminal.reset_input()
}

async fn terminal_stage(
    terminal: &mut crate::ui::TerminalGuard,
    title: &str,
    body: &str,
    key: char,
) -> Result<()> {
    loop {
        terminal
            .terminal
            .draw(|frame| super::super::protected::draw(frame, title, body))?;
        if matches!(terminal_input(terminal).await?, Event::Key(event) if event.kind == KeyEventKind::Press && event.code == KeyCode::Char(key))
        {
            return Ok(());
        }
    }
}

async fn terminal_share(
    backend: &LocalBackend,
    session: &Session,
) -> Result<(HostUi, mpsc::Sender<HostNotice>, oneshot::Sender<()>)> {
    let identity = EndpointIdentity::memory_only()?;
    let invitation = Invitation::new(
        super::super::identity::RelayOrigin::parse("https://relay.example")?,
        identity.public_key(),
        ShareRole::Control,
        NOW,
    )?;
    backend
        .begin_share(
            &session.id,
            invitation.routing_id().into(),
            ShareRole::Control,
            EXPIRES,
        )
        .await?;
    let (task, sender, release) = held_task(invitation.routing_id());
    let mut sharing = host(session, task);
    sharing.panel = Some(Panel {
        title: "Private pairing fixture".into(),
        body: invitation.protected_text()?,
        answer: None,
    });
    Ok((sharing, sender, release))
}

async fn terminal_host_flow(config: &RemoteTerminalConfig) -> Result<()> {
    let (_directory, backend, session) = backend().await?;
    let (mut sharing, sender, _release) = terminal_share(&backend, &session).await?;
    let mut app = App::new(session.clone());
    let args = Args::try_parse_from(["ejm-cli", "--replay"])?;
    let mut terminal = crate::ui::TerminalGuard::enter()?;
    terminal_panel(&mut terminal, &mut sharing).await?;

    let (answer, receive) = oneshot::channel();
    sender
        .send(HostNotice::Confirm {
            fingerprint: "public controller fingerprint fixture".into(),
            answer,
        })
        .await?;
    sharing.poll(&mut app, &backend, NOW).await;
    terminal_panel(&mut terminal, &mut sharing).await?;
    anyhow::ensure!(receive.await?, "local controller confirmation was refused");
    sender.send(HostNotice::Connected).await?;
    sharing.poll(&mut app, &backend, NOW).await;
    terminal_stage(&mut terminal, "Host paired", "S stops this share.", 's').await?;
    sharing
        .command("/remote stop", &backend, &args, &session.id)
        .await?;
    anyhow::ensure!(
        backend.shared_session().await.is_none() && sharing.panel.is_none(),
        "stop left remote authority or a private panel"
    );
    terminal_stage(
        &mut terminal,
        "Sharing stopped",
        "R creates a new local share.",
        'r',
    )
    .await?;

    let (mut replacement, _sender, _release) = terminal_share(&backend, &session).await?;
    terminal_panel(&mut terminal, &mut replacement).await?;
    terminal_stage(
        &mut terminal,
        "Switch shared session",
        "N selects another local session.",
        'n',
    )
    .await?;
    let next = backend
        .create_session(SessionOptions {
            cwd: session.cwd.clone(),
            title: "selected session changed".into(),
        })
        .await?;
    app.switch_session(App::new(next));
    anyhow::ensure!(
        replacement.session_changed(&app.session.id),
        "session change was not detected"
    );
    replacement.stop(&backend).await;
    anyhow::ensure!(
        backend.shared_session().await.is_none()
            && replacement.panel.is_none()
            && replacement.session.is_none(),
        "session change left sharing active"
    );
    anyhow::ensure!(
        app.composer.text.is_empty()
            && app
                .blocks
                .iter()
                .all(|block| !block.text.contains(&config.input)
                    && !block.text.contains("ejm-remote:v1:")),
        "private pairing entered the conversation"
    );
    anyhow::ensure!(
        backend.events(&session.id, 0, 512).await?.is_empty(),
        "private pairing entered durable session events"
    );
    terminal_stage(
        &mut terminal,
        "Selected session changed",
        "Q leaves the terminal fixture.",
        'q',
    )
    .await?;
    drop(terminal);
    backend.shutdown().await
}

async fn terminal_private_boundary(config: &RemoteTerminalConfig) -> Result<()> {
    const PUBLIC_INPUT: &str = "safe boundary input";
    let (_directory, backend, session) = backend().await?;
    let mut app = App::new(session.clone());
    let args = Args::try_parse_from(["ejm-cli", "--replay"])?;
    let mut terminal = crate::ui::TerminalGuard::enter()?;
    app.notice("Ordinary input ready");
    loop {
        let snapshot = backend.status().await;
        terminal
            .terminal
            .draw(|frame| crate::render::draw(frame, &mut app, &args, &snapshot))?;
        match terminal_input(&mut terminal).await? {
            Event::Paste(text) => app.composer.insert(&Zeroizing::new(text)),
            Event::Key(key) if key.kind == KeyEventKind::Press => {
                if key.code == KeyCode::Enter {
                    anyhow::ensure!(
                        app.composer.take() == PUBLIC_INPUT,
                        "private queued input crossed into an ordinary submission"
                    );
                    break;
                }
                crate::ui::edit_composer(key, &mut app);
            }
            _ => {}
        }
        anyhow::ensure!(
            !app.composer.text.contains(&config.input),
            "private queued input crossed into the ordinary draft"
        );
    }
    app.composer.history(true);
    app.composer.history(true);
    anyhow::ensure!(
        app.composer.text == PUBLIC_INPUT
            && app
                .blocks
                .iter()
                .all(|block| !block.text.contains(&config.input)),
        "private queued input entered ordinary history"
    );
    anyhow::ensure!(
        backend.events(&session.id, 0, 512).await?.is_empty(),
        "private queued input entered durable session events"
    );
    terminal_stage(
        &mut terminal,
        "Private input boundary passed",
        "Q leaves the terminal fixture.",
        'q',
    )
    .await?;
    drop(terminal);
    backend.shutdown().await
}

#[expect(
    clippy::panic,
    reason = "The PTY supervisor verifies private input is discarded before panic restores echo."
)]
fn terminal_panic_fixture() -> ! {
    panic!("private terminal panic cleanup fixture");
}

#[tokio::test]
#[ignore = "PTY supervisor drives private input, pairing panels and terminal restoration"]
async fn remote_terminal_interaction_fixture() -> Result<()> {
    let config = terminal_config()?;
    let mode = std::env::var("EJM_REMOTE_TERMINAL_CASE")
        .context("remote terminal fixture case missing")?;
    #[cfg(unix)]
    let mut panic_signal =
        tokio::signal::unix::signal(tokio::signal::unix::SignalKind::user_defined1())?;
    #[cfg(windows)]
    let mut panic_signal = tokio::signal::windows::ctrl_break()?;
    let input = tokio::select! {
        result = super::super::protected::read_invitation(CancellationToken::new()) => result,
        () = crate::ui::termination_signal(), if mode != "panic" => {
            anyhow::ensure!(mode == "signal", "terminal fixture interrupted");
            return Ok(());
        }
        () = async {
            #[cfg(any(unix, windows))]
            let _ = panic_signal.recv().await;
            #[cfg(not(any(unix, windows)))]
            std::future::pending::<()>().await;
        }, if mode == "panic" => terminal_panic_fixture(),
    };
    if matches!(mode.as_str(), "flow" | "queued-complete" | "queued-partial") {
        anyhow::ensure!(
            input?.as_str() == config.input,
            "protected invitation input changed"
        );
        if mode == "flow" {
            terminal_host_flow(&config).await
        } else {
            terminal_private_boundary(&config).await
        }
    } else {
        anyhow::ensure!(
            matches!(mode.as_str(), "cancel" | "interrupt" | "error") && input.is_err(),
            "protected input did not cancel or reject the invalid paste"
        );
        Ok(())
    }
}
