Revised source snapshot, October 20, 2026.

Obsolete product identities were normalized after the native film capture.
The package manifest is ejm.package.json. The archived registry origin is
https://registry.example.invalid, a reserved placeholder with no service.
No registry operation should use this archived origin. Current source
requires an explicitly configured origin.

This snapshot is not the byte-identical source of the recorded binary.
The original capture metadata retains its historical file and binary hashes.
The revised snapshot has not been rebuilt or recaptured. Rebuild and rerun
before drawing conclusions about its behavior or performance.
